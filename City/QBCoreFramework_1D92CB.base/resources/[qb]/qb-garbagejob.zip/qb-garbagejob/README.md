# qb-garbagejob
Garbage Job For QB-Core
